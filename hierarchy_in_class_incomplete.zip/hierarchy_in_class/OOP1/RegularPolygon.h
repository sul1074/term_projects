#pragma once

#include "GameObject.h"
#include <vector>
#include <algorithm>
#include <cmath>
#include "Enemy.h"
#include "Label.h"

using namespace std;

#define PI 3.14159265f

class RegularPolygon :
    public GameObject
{
    vector<Vector2> points;
    float   radius;
    float   rotationSpeed;
    bool    selected;
    int     blinking;

    Label* label;

    void configure(unsigned int n) {
        points.clear();
        if (n == 0) return;
        
        double angleInRadian = 2.0 * PI / n;

        for (unsigned int i = 0; i < n; i++) {
            Debug::Log("shape[%d] (%f, %f)", i, cos(angleInRadian * i), cos(angleInRadian * i));
            points.push_back({ (float)cos(angleInRadian * i), (float)sin(angleInRadian * i) });
        }
    }

    void rotate();

public:
    // set the center position to its game object position.
    RegularPolygon(GameObject* parent, int n, const Vector2& center, float radius) 
        : GameObject(parent, "polygon", center, { (int)radius, (int)radius }, true),
        radius(radius), rotationSpeed(PI / 180.0f), // rotation speed by one degree
        selected(false), blinking(0),
        label(nullptr)        
    {
        configure(n);

        label = new Label(this);
        GameObject::Add(label);
        label->setVisible(false);
        auto enemy = new Enemy(this, "---------------", { -2, -1 }, { 5, 3 }, true);
        GameObject::Add(enemy);
        
    }

    void update() override;
    void draw() override;

    void setSelected(bool selected = true) {
        if (this->selected == selected) return;
        this->selected = selected;
        blinking = (int)selected;
    }
    bool isSelected() const { return selected; }

    bool isOverlapping(const Vector2& pos, const Dimension& dim) const override {
        auto center = getPosition();
        return pos.x <= center.x && pos.x + dim.x > center.x && pos.y <= center.y && pos.y + dim.y > center.y;
    }

    RegularPolygon& operator++() {
        configure((int)points.size() + 1);
        return *this;
    }
    RegularPolygon operator--(int unused) {
        auto temp(*this);
        configure((int)points.size() - 1);
        if (points.size() < 2) destroy();
        return temp;
    }
};

