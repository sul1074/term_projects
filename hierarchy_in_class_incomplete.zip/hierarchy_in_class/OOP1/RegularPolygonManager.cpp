#include "RegularPolygonManager.h"
#include "InputManager.h"
#include "Canvas.h"
#include <algorithm>


RegularPolygonManager::RegularPolygonManager(GameObject* parent, int n): GameObject(parent, "", { 0, 0 }, { 1,1 }, false)
{
    selector = new Selector(this);
    for (int i = 0; i < n; i++) {
        auto canDim = canvas.getDimension();
        auto polygon = new RegularPolygon(this, rand() % 3 + 2, 
            { rand() % canDim.x, rand() % canDim.y }, (float)((rand() % 5) + 5) );
        GameObject::Add(polygon);
    }
    GameObject::Add(selector);
}


void RegularPolygonManager::update() {
	if (input.getMouseButton(0)) {
        auto start = selector->getPosition();
        auto end = selector->getEndPosition();

        auto minX = start.x < end.x ? start.x : end.x;
        auto maxX = start.x >= end.x ? start.x : end.x;
        auto minY = start.y < end.y ? start.y : end.y;
        auto maxY = start.y >= end.y ? start.y : end.y;

        Vector2 topLeft{ minX, minY };
        Vector2 topRight{ maxX, minY };
        Vector2 bottomLeft{ minX, maxY };
        Vector2 bottomRight{ maxX, maxY };

        auto dim = bottomRight - topLeft;
        if (start.equalApproximately(end)) return;
        auto firstNonOverlapping = stable_partition(children.begin(), children.end(), [=](auto obj) {
            return obj->isOverlapping(topLeft, dim);
        });
        if (firstNonOverlapping != children.end()) {
            selector->setText(to_string(firstNonOverlapping - children.begin()-1) );
        }
        for_each(children.begin(), firstNonOverlapping, [](auto obj) {
            auto polygon = dynamic_cast<RegularPolygon*>(obj);
            if (polygon == nullptr) return;
            polygon->setSelected();
            });
        for_each(firstNonOverlapping, children.end(), [](auto obj) {
            auto polygon = dynamic_cast<RegularPolygon*>(obj);
            if (polygon == nullptr) return;
            polygon->setSelected(false);
            });
    }
}