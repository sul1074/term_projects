#include "Selector.h"
#include "Canvas.h"

void Selector::draw()
{
    if (end.equalApproximately(getPosition())) return;
    canvas.drawRectangle(getWorldPosition(), end, isVisible());
}
