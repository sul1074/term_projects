#pragma once
#include "GameObject.h"
#include "InputManager.h"
#include <vector>
#include "Label.h"

using namespace std;

class Selector :
    public GameObject
{
    Position end;

    Label* label;

public:
    Selector(GameObject* parent) : GameObject(parent, "", { 0, 0 }, { 1,1 }, false), end{ 0, 0 } {
        end = getPosition();
        label = new Label(this);
        label->setVisible(false);
        GameObject::Add(label);
    }

    void setText(const string& text) const {
        label->setText(text);
    }

    Position getEndPosition() const { return end; }

    void update() override 
    {
        if (input.getMouseButtonDown(0)) {
            end = input.getMousePosition();
            setPosition(end);
            setVisible(true);
            label->setVisible(true);
        }
        if (input.getMouseButton(0)) {
            end = input.getMousePosition();
        }
        if (input.getMouseButtonUp(0)) {
            end = input.getMousePosition();
            setPosition(end);
            setVisible(false);
            label->setVisible(false);
        }
    }
    void draw() override;
};

