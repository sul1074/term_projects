#include <cstdlib> // include rand()
#include <Windows.h>
#include <conio.h>
#include "GameObject.h"
#include "Canvas.h"
#include "Cards.h"
#include "Enemy.h"
#include "BlinkablePlayer.h"
#include "Bullet.h"
#include "InputManager.h"
#include <algorithm>
#include "RegularPolygon.h"
#include "RegularPolygonManager.h"
#include "ConfirmationPanel.h"
#include <string>

using namespace std;

vector<GameObject*> GameObject::objs;
vector<GameObject*> GameObject::pendingObjs;
bool GameObject::exit_flag = false;


void GameObject::draw() { 
	if (alive == true) canvas.draw(shape, getWorldPosition(), dimension, visible);
}

void GameObject::Initialize()
{
	objs.clear();

	/*
	auto dim = Canvas::GetInstance().getDimension();
	for (int i = 0; i < 5; i++)
	{
		switch (rand() % 2)
		{
		case 0:
			GameObject::Add(new BlinkablePlayer(nullptr, "########  ##########    ##    ", Position{ rand() % dim.x, rand() % dim.y }, Dimension{ 6, 5 }, true));
			break;
		case 1:
			GameObject::Add(new Enemy(nullptr, "\xb2\xb2\xb2\xb2\xb2   \xb2\xb2\xb2\xb2\xb2   \xb2\xb2\xb2\xb2", Position{ rand() % dim.x, rand() % dim.y }, Dimension{ 4, 5 }, true));
			break;
		}
	}
	GameObject::Add(new Cards(nullptr, 7, 9, { 5, 7 }));
	
	*/
	
	GameObject::Add(new RegularPolygonManager(nullptr, 5));
}

void GameObject::Add(GameObject* obj)
{
	if (obj == nullptr) return;

	pendingObjs.push_back(obj);
}

void GameObject::Remove(GameObject* obj)
{
	if (obj == nullptr) return;

	auto it = find(objs.begin(), objs.end(), obj);
	if (it == objs.end()) return;

	objs.erase(it);
	delete obj;
}

void GameObject::ProcessInput(bool& exit_flag, InputManager& input)
{
	Bullet* bullet = nullptr;
	BlinkablePlayer* player = nullptr;


	if (input.getKey('I')) {
		for (auto obj : objs)
		{
			auto pos = obj->getPosition();
			Debug::Log("[%s (%2d, %2d) %d %d] ", obj->getShape(), (int)pos.x, (int)pos.y, obj->isVisible(), obj->isAlive());
		}
		Bullet::printNumberOfCreatedBullets();
	}
	if (input.getKeyDown(VK_SPACE)) {
		auto canvasDim = Canvas::GetInstance().getDimension();

		// pick any player closer to a randomized position.
		auto randPos = Vector2{ (float)(rand() % (canvasDim.x - 5)), (float)(rand() % (canvasDim.y - 2)) };
		for (auto obj : objs)
		{
			BlinkablePlayer* source = dynamic_cast<BlinkablePlayer*>(obj);
			if (source == nullptr) continue;
			if (source->isVisible() == false) continue;
			if (player == nullptr) {
				player = source;
				continue;
			}
			// player is not null, that is it is assumed to find any player during array traversal.
			if ((source->getPosition()).distance(randPos) < (player->getPosition()).distance(randPos))
				player = source;
		}
		if (player != nullptr) { // if found
			Enemy* enemy = nullptr;
			auto found = find_if(objs.begin(), objs.end(), [](auto obj) { return dynamic_cast<Enemy*>(obj) != nullptr; });
			if (found != objs.end()) enemy = static_cast<Enemy*>(*found);
			auto targetPos = Vector2{ (float)(rand() % canvasDim.x), (float)(rand() % canvasDim.y) };
			if (enemy) targetPos = enemy->getPosition();

			bullet = new Bullet(nullptr, "O", targetPos, { 1,1 }, 1.0f);
			GameObject::Add(bullet);
			bullet->fire(player, targetPos);

			player->setBlinkingPeriod(30);
		}
	}

	if (input.getKeyDown('Q')) {
		auto canvasDim = Canvas::GetInstance().getDimension();
		auto confirm = new ConfirmationPanel(nullptr, { canvasDim.x / 2.0f - 10, canvasDim.y / 2.0f - 2 }, { 20, 5 });
		GameObject::Add(confirm);
	}
}

void GameObject::UpdateAll()
{
	for (auto obj : objs) {
		if (obj == nullptr || obj->isAlive() == false) continue;

		auto confirm = dynamic_cast<ConfirmationPanel*>(obj);
		if (confirm != nullptr) {
			auto result = confirm->getResult();
			if (result == "okay") {
				GameObject::exit_flag = true;
				confirm->destroy();
				continue;
			}
			if (result == "cancel") {
				GameObject::exit_flag = false;
				confirm->destroy();
				continue;
			}
		}
		auto parent = obj->getParent();
		if (parent != nullptr) continue;
		obj->updateInHierarchy({ 0, 0 });
	}


	RemoveDeadObjects();
}

void GameObject::DrawAll()
{
	for (auto obj : objs) {
		if (obj->isAlive() == false) continue;
		auto parent = obj->getParent();
		if (parent != nullptr) continue;
		obj->drawInHierarchy();
	}
}

void GameObject::ExamineCollision()
{
	for (auto it = objs.begin(); it != objs.end(); it++)
	{
		auto obj = *it;
		if (obj->isAlive() == false) continue;
		ICollidable* c_i = dynamic_cast<ICollidable*>(obj);
		if (c_i == nullptr) continue;
		for (auto jt = it + 1; jt != objs.end() && obj->isAlive() == true; jt++)
		{
			auto other = *jt;
			if (other->isAlive() == false) continue;
			ICollidable* c_j = dynamic_cast<ICollidable*>(other);
			if (c_j == nullptr) continue;
			if (obj->isColliding(other) == false)  continue;
			c_j->onCollision(obj);
			c_i->onCollision(other);
		}
	}
	RemoveDeadObjects();
}

void GameObject::RemoveDeadObjects()
{	
	auto FirstToRemove = stable_partition(objs.begin(), objs.end(), [](auto obj) { return obj->isAlive(); });
	for_each(FirstToRemove, objs.end(), [](auto obj) {
		delete obj;
		});

	objs.erase(FirstToRemove, objs.end());

	while (pendingObjs.size())
	{
		auto obj = pendingObjs.back();		
		objs.push_back(obj);
		auto parent = obj->getParent();
		if (parent != nullptr)
			parent->addChild(obj);		
		pendingObjs.pop_back();
	}
}

void GameObject::Deinitialize()
{
	while (!objs.empty()) {
		auto obj = objs.back();
		objs.pop_back();
		delete obj;
	}
	objs.clear();
}