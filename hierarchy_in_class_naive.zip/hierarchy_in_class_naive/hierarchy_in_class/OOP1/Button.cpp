#include "Button.h"

void Button::draw()
{
	auto worldPos = getWorldPosition();
	auto dim = getDimension();
	int len = (int)strlen(getShape());

	auto offset = Vector2{ (dim.x - len) / 2.0f, dim.y / 2.0f }; // align the text in the middle

	Panel::draw();
	canvas.draw(getShape(), worldPos + Vector2{ offset.x, 1 }, Dimension{ len,  (int)offset.y }, isVisible());
}
