#include "ConfirmationPanel.h"
#include "Button.h"


ConfirmationPanel::ConfirmationPanel(GameObject* parent, const Vector2& pos, const Dimension& dim)
    : Panel(parent, "", pos, dim), 
    result("undecided"), ok(nullptr), cancel(nullptr)
{  
    cancel = new Button(this, "cancel", { 1, 1 }, { 7, 3 });
    ok = new Button(this, "okay", { 12, 1 }, { 7, 3 });
    GameObject::Add(cancel);
    GameObject::Add(ok);
}

void ConfirmationPanel::update()
{
    if (cancel->isDone() == true) {
        result = "cancel";
    }
    if (ok->isDone() == true) {
        result = "okay";
    }
}