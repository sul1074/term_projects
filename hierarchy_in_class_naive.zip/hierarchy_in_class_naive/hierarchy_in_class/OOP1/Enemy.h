#pragma once
#include "GameObject.h"
#include "ICollidable.h"

// enemy

class Enemy : public GameObject, public ICollidable {

	float hp;
	int n_frames;

public:

	Enemy(GameObject* parent, const char* shape, const Vector2& pos, const Dimension& dim, bool visible)
		: GameObject(parent, shape, pos, dim, visible), hp(5.0f), n_frames(0)
	{}

	void setTimeout(int n_frames)
	{
		this->n_frames = n_frames;
	}

	void onHit(float damage)
	{
		hp = hp - damage;
		if (hp > 0.0f) {
			setTimeout(100);
			return;
		}

		destroy();
	}

	void draw() override;

	void onCollision(GameObject* collided) override {};

	~Enemy() {}

};