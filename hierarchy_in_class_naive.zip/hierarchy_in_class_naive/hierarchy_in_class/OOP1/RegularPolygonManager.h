#pragma once
#include "GameObject.h"
#include "RegularPolygon.h"
#include "Selector.h"
#include <vector>

using namespace std;

class RegularPolygonManager :
    public GameObject
{
    Selector* selector;

public:
    RegularPolygonManager(GameObject* parent, int n);

    void update() override;
};

