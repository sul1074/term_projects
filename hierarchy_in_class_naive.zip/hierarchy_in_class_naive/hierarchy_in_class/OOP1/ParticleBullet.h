#pragma once
#include "Bullet.h"

// particle bullet
class ParticleBullet : public Bullet {
	int		n_frames_to_disappear;

public:

	ParticleBullet(GameObject* parent, const Vector2& pos, const Vector2& dir)
		: Bullet(parent, "*", pos, { 1, 1 }, 0.005f, true, dir), n_frames_to_disappear(200)
	{}

	void onCollision(GameObject* collided) override;

	void update() override
	{
		Bullet::update();

		if (isAlive() == false || isVisible() == false) return;

		if (n_frames_to_disappear > 0) {
			--n_frames_to_disappear;
		}
		if (n_frames_to_disappear > 0) return;
		destroy();
	}

	~ParticleBullet()
	{
		n_frames_to_disappear = 0;
	}
};

