#pragma once
#include "GameObject.h"
#include <string>

using namespace std;

class Label :
    public GameObject
{
    string text;

public:
    Label(GameObject* parent) : GameObject(parent, "label", { 0, 0 }, { 1,1 }), text("0")
    {}

    void setText(const string& text) { this->text = text; }

    void draw() override {
        canvas.draw(text.c_str(), getWorldPosition(), { (int)text.length(), 1 }, isVisible());
    }


};

