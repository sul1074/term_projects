#pragma once
#include "Panel.h"
#include "Button.h"

using namespace std;

class ConfirmationPanel :
    public Panel
{
    string result;
    Button* ok;
    Button* cancel;

public:
    ConfirmationPanel(GameObject* parent, const Vector2& pos, const Dimension& dim);

    string getResult() const { return result; }

    void update() override;
};

