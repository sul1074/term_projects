#include "Panel.h"

void Panel::draw()
{
	auto worldPos = getWorldPosition();

	canvas.draw(' ', worldPos, getDimension(), isVisible());
	canvas.drawRectangle(worldPos - Vector2{ 1, 1 }, worldPos + getDimension(), isVisible());
}