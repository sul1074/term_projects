#pragma once
#include "Panel.h"
#include <string>

using namespace std;

class Button :
    public Panel
{
    bool done;

public:
    Button(GameObject* parent, const string& text, const Vector2& pos, const Dimension& dim) 
        : Panel(parent, text, pos, dim), done(false)
    {}

    void update() override {
        auto worldPos = getWorldPosition();
        if (input.getMouseButtonDown(0)) {
            Vector2 mousePos = input.getMousePosition();
            if (isInside(mousePos)) done = true;
        }
    }

    bool isDone() const { return done; }

    void draw() override;
};

