#pragma once

#include <iostream>
#include <vector>
#include "Canvas.h"
#include "InputManager.h"
#include "Utils.h"

class InputManager;
class GameObject;

class GameObject
{
private:

	char* shape;
	Dimension dimension; // x: width, y: height;
	Vector2 position;	// local position
	Vector2 parentWorldPosition; // screen psotion, world position, global position

	Vector2 direction;
	bool	visible;
	bool	alive;


	
	static void RemoveDeadObjects();

	void updateInHierarchy(const Vector2& worldPos = { 0,0 })
	{
		parentWorldPosition = worldPos;
		if (isAlive() == false) return;
		
		update();
		if (isAlive() == false) return;
		for (auto child : children) 
			child->updateInHierarchy( worldPos + position );
	}

	void drawInHierarchy()
	{
		if (isAlive() == false) return;

		draw();
		for (auto child : children)
			child->drawInHierarchy();
	}


protected:

	Canvas& canvas;
	InputManager& input;

	std::vector<GameObject*> children;

	GameObject* parent;


	static std::vector<GameObject*> objs;
	static std::vector<GameObject*> pendingObjs;

	


	Vector2 getParentWorldPosition() const { return parentWorldPosition;  }

	Vector2 getWorldPosition() const { return parentWorldPosition + position;  }

public:

	GameObject(GameObject* parent, const char* shape, const Vector2& pos = { 0.0f, 0.0f }, const Dimension& dim = Dimension{ 1, 1 }, bool visible = true, const Vector2& dir = { 0.0f, 0.0f })
		: parent(parent), canvas( Canvas::GetInstance()   ), input( InputManager::GetInstance() ),
		shape(new char[strlen(shape) + 1]), position(pos), dimension(dim), visible(visible), direction(dir), alive(true),
		parentWorldPosition(pos) // may not point to the exact global location. It will be updated for every update call.
	{
		if (this->shape != nullptr)
			strcpy(this->shape, shape);
	}

	GameObject(GameObject* parent, const char* shape, int pos, bool visible)
		: GameObject(parent, shape, Vector2((float)pos, 0.0f), Dimension((int)strlen(shape), 1))
	{}

	GameObject(const GameObject& other)
		: GameObject(other.parent, other.shape, other.position, other.dimension, other.visible, other.direction)
	{}

	void setParent(GameObject* parent)
	{
		this->parent = parent;
	}

	GameObject* getParent() const { return parent; }


	void addChild(GameObject* child)
	{
		children.push_back(child);
	}

	void removeChild(GameObject* child)
	{
		auto it = find(children.begin(), children.end(), child);
		if (it != children.end()) children.erase(it);
	}

	Vector2 getPosition() const { return position;  }
	void	setPosition(const Vector2& pos) { position = pos;  }

	Vector2 getDirection() const { return direction; }
	void	setDirection(const Vector2& dir) { direction = dir.unit(); }

	Dimension getDimension() const { return dimension;  }
	void	changeDimension(const Dimension& dim) { dimension = dim; }

	const char* getShape() const { return this->shape; } // getter
	void	setShape(const char* shape) { 
		delete[] this->shape;
		this->shape = new char[strlen(shape) + 1];
		strcpy(this->shape, shape); 
	} // setter
	int		getShapeSize() const { return (int)strlen(this->shape); }

	bool	isVisible() const { return visible; } // gettter
	void	setVisible(bool visible = true) { this->visible = visible; } // setter

	bool	isAlive() const { return alive; }
	void	destroy() {
		this->alive = false;
		setVisible(alive);
		if (parent != nullptr) parent->removeChild(this);
		for (auto child : children) child->destroy();
	}

	virtual void draw();

	void move(float speed) { position = { direction.x * speed, direction.y * speed }; }

	void move(const Vector2& direction) { position.x += direction.x; position.y += direction.y; }

	virtual void update() {}

	bool isColliding(GameObject* other) const {
		if (other == nullptr) return false;
		return isOverlapping(other->getPosition(), other->getDimension());
	}

	virtual bool isOverlapping(const Vector2& pos, const Dimension& dim) const {
		auto myPos = getPosition();
		auto myDim = getDimension();
		if (myPos.x + myDim.x < pos.x || myPos.y + myDim.y < pos.y) return false;
		if (pos.x + dim.x < myPos.x || pos.y + dim.y < myPos.y) return false;
		return true;
	}

	bool isInside(const Vector2& pos) const {
		auto worldPos = getWorldPosition();
		return worldPos.x <= pos.x && worldPos.x + dimension.x > pos.x && worldPos.y <= pos.y && worldPos.y + dimension.y > pos.y;
	}

	virtual ~GameObject() {
		delete[] this->shape;
		this->shape = nullptr;
		this->visible = false;
		this->alive = false;
	}

	static void Initialize();
	static void Add(GameObject* obj);
	static void Remove(GameObject* obj);
	static void ProcessInput(bool& exit_flag, InputManager& input);
	static void UpdateAll();
	static void DrawAll();
	static void Deinitialize();
	static void ExamineCollision();
};


