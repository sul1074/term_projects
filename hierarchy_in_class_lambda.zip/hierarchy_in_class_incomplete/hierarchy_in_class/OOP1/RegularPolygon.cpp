#include "RegularPolygon.h"
#include "InputManager.h"
#include "Canvas.h"

void RegularPolygon::rotate()
{
	if (selected == false) return;
	float speed = rotationSpeed;
	for_each(points.begin(), points.end(), [=](auto& point) {
		point = Vector2{ cos(speed) * point.x + sin(speed) * point.y, 
			-1.0f * sin(speed) * point.x + cos(speed) * point.y };
	});	
}

void RegularPolygon::update()
{
	label->setVisible(selected);
	if (selected == false) return;
	
	label->setText(to_string(points.size()));

	if (input.getKeyDown(VK_RIGHT)) ++(*this);
	
	if (input.getKeyDown(VK_LEFT)) {
		(*this)--;
		if (this->isAlive() == false) return;
	}

	if (input.getKeyDown(VK_SPACE)) {
		rotationSpeed = (PI / 180.0f); // reset rotation speed
		rotate();
	}
	
	if (input.getKey(VK_SPACE)) {
		rotationSpeed += (PI / 180.0f); // increment rotation speed by one degree.
		rotate();
	}
	if (input.getKey(VK_UP)) {
		if (radius < 30.0f) 
			radius++;
	}
	if (input.getKey(VK_DOWN)) {
		if (radius > 1.0f) 
			radius--;
	}
	if (input.getKey('A')) setPosition( getPosition() + Vector2{ -1, 0 } );
	if (input.getKey('D')) setPosition( getPosition() + Vector2{ 1, 0 } );
	if (input.getKey('W')) setPosition( getPosition() +  Vector2{0, -1} );
	if (input.getKey('S')) setPosition( getPosition() + Vector2{0, 1 } );
}


void RegularPolygon::draw()
{
	bool show = true;
	if (blinking != 0) { show = (bool)(blinking++ % 10); }
	if (show == true) {
		auto worldPos = getWorldPosition();
		for (int i = 0; i < points.size(); i++) {
			canvas.drawLine('#',
				points.at(i % (int)points.size()) * radius + worldPos ,
				points.at((i + 1) % (int)points.size()) * radius + worldPos );
		}
	}
}

