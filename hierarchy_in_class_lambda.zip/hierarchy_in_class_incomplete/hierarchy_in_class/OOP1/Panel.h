#pragma once
#include "GameObject.h"
#include "Utils.h"
#include <string>

using namespace std;

class Panel :
    public GameObject
{
    
public:
    Panel(GameObject* parent, const string& text, const Vector2& pos, const Dimension& dim): GameObject(parent, text.c_str(), pos, dim)
    {}

    void draw() override;
};

