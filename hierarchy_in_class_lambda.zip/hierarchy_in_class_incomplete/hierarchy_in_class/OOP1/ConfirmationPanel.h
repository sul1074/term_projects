#pragma once
#include "Panel.h"
#include "Button.h"
#include <functional>

using namespace std;

class ConfirmationPanel :
    public Panel
{
    string result;
    Button* ok;
    Button* cancel;

    

    function<void(GameObject*)> cancelLambda;

    function<void(GameObject*)> okayLambda;


public:
    ConfirmationPanel(GameObject* parent, const Vector2& pos, const Dimension& dim, function<void(GameObject*)> cancel,
        function<void(GameObject*)> okay);
};

