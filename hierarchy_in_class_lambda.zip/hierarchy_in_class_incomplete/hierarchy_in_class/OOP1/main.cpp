﻿#include <iostream>
#include <cstdlib> // include rand()
#include <Windows.h>
#include <conio.h>
#include "GameObject.h"
#include "Utils.h"
#include "InputManager.h"



int main()
{
	GameObject::Initialize();
    InputManager& input = InputManager::GetInstance();
	Canvas& canvas = Canvas::GetInstance();
	bool exit_flag = false;
    
	while (exit_flag == false)
	{
		canvas.clear();
		input.readEveryFrame();

		GameObject::ProcessInput(exit_flag, input);

		GameObject::ExamineCollision();

		GameObject::UpdateAll();
		
		GameObject::DrawAll();

		canvas.render();
		Sleep(10);
	}

    GameObject::Deinitialize();

	return 0;
}

