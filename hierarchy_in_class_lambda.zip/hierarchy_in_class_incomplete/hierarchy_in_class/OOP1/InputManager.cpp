#include "InputManager.h"

InputManager* InputManager::instance = nullptr;


