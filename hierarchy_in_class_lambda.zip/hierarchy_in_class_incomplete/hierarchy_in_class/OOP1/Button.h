#pragma once
#include "Panel.h"
#include <string>
#include <functional>

using namespace std;

class Button :
    public Panel
{
    bool done;
    function<void(GameObject*)> action;

public:
    Button(GameObject* parent, const string& text, const Vector2& pos, const Dimension& dim, function<void(GameObject*)> action) : Panel(parent, text, pos, dim), 
        done(false), action(action)
    {}

    void update() override {
        auto worldPos = getWorldPosition();
        if (input.getMouseButtonDown(0)) {
            Vector2 mousePos = input.getMousePosition();
            if (isInside(mousePos)) action(this->getParent());
        }
    }

    bool isDone() const { return done; }

    void draw() override;
};

